new Clipboard('.clipboard-btn');function startOneCommandArtyom(){artyom.fatality();setTimeout(()=>{artyom.initialize({lang:"en-GB",continuous:!1,listen:!0,debug:!0,speed:1}).then(()=>{console.log("Ready to work !")})},250)}
const speechCommands=[{indexes:["hello","good morning","good evening"],action(){artyom.say("Hey Robert! How are you today?")}}];artyom.addCommands(speechCommands);function startArtyom(){artyom.initialize({lang:"en-GB",continuous:!1,listen:!0,debug:!0,speed:1})}
const translatorApp=new Vue({el:"#translatorApp",data:{loader:!1,snackbar:!1,snackbar_msg:null,languages:[],selected_language:"en",text_to_translate:null,translated_text:null,image_url:null,img_dialog:!1,image_url_field:!0,spinner:!1,convert_button:!1,info:!0,translated_text_title:"Translated Text",endpoint:"https://translate.yandex.net",yandex_api_key:"trnsl.1.1.20170609T083328Z.bc764b99ad68e76a.6e5983803d01cb65a2b4bbfa1b2cfd872599d055"},created(){this.fetchLanguages()},methods:{translate(){const self=this;if(!this.text_to_translate)return!1
this.translated_text_title="Translating..."
this.loader=!0
axios.get(`${this.endpoint}/api/v1.5/tr.json/translate?key=${this.yandex_api_key}&text=${this.text_to_translate}&lang=${this.selected_language}`).then(response=>{self.translated_text_title="Translated Text"
self.loader=!1
self.translated_text=response.data.text[0]
console.log(response.data)}).catch(function(err){this.snackbar_msg="An error occured. Check the console."
this.snackbar=!0
console.log(err)})},fetchLanguages(){const self=this;axios.get(`${this.endpoint}/api/v1.5/tr.json/getLangs?ui=en&key=${this.yandex_api_key}`).then(response=>{const languages=Object.keys(response.data.langs).map(key=>({'code':key,'lang':response.data.langs[key]}));self.languages=languages
self.snackbar_msg="Languages loaded"
self.snackbar=!0}).catch(err=>{console.log(err)})},startListening(){const self=this;this.snackbar_msg="Microphone on"
this.snackbar=!0
startOneCommandArtyom()
artyom.redirectRecognizedTextOutput((recognized,isFinal)=>{if(isFinal){self.text_to_translate=recognized}else{self.text_to_translate="Recognizing..."}})},setLanguage(code){this.selected_language=code
this.snackbar_msg=`Language set to ${code}`
this.snackbar=!0},listen(){const self=this;const selected_language=this.selected_language;let lang=null;if(selected_language=="en"){lang="en-GB"}
else if(selected_language=="ru"){lang="ru-RU"}
else if(selected_language=="ja"){lang="ja-JP"}
else if(selected_language=="nl"){lang="nl-NL"}
else if(selected_language=="id"){lang="id-ID"}
else if(selected_language=="pl"){lang="pl-PL"}
else if(selected_language=="zh"){lang="zh-CN"}
else if(selected_language=="pt"){lang="pt-PT"}
else if(selected_language=="it"){lang="it-IT"}
else if(selected_language=="fr"){lang="fr-FR"}
else{const text="Sorry. That language is not yet supported.";this.snackbar_msg=text
this.snackbar=!0
artyom.say(text);return!1}
artyom.initialize({lang,continuous:!1,listen:!1,debug:!0,}).then(()=>{artyom.say(self.translated_text);artyom.fatality()})},copied(){this.snackbar_msg="Copied to clipboard"
this.snackbar=!0},detectImage(){const self=this;if(!this.image_url)return!1
this.snackbar_msg="Converting. Please wait..."
this.snackbar=!0
this.image_url_field=!1
this.spinner=!0
this.convert_button=!0
Tesseract.recognize(this.image_url).then(result=>{console.log(result)
self.snackbar_msg="Converted"
self.snackbar=!0
self.image_url_field=!0
self.spinner=!1
self.convert_button=!1
self.image_url=null
self.text_to_translate=result.text})}}})